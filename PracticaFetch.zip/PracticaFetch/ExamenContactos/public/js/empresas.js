//Toda la wea
const url = 'http://localhost:3000/api/companies/';
const table = document.querySelector('#companies');
const TBODY = document.getElementsByTagName('tbody')[0];
const NAME = document.querySelector('#name');
const industry = document.querySelector('#industry');
const sector = document.querySelector('#sector');
const capital = document.querySelector('#capital');
const enviar = document.querySelector('#Crear');
const tr = document.getElementsByTagName('tr');
const selectedCompanies = JSON.parse(localStorage.getItem("selectedCompanies")) || [];
//Mostrar las empresas
cargarEmpresas();
function cargarEmpresas() {
    fetch(url)
        .then(response => response.json())
        .then(data => {
            console.log(data);
            TBODY.innerHTML = '';
            data.forEach((empresa, index) => {
                let linea = document.createElement('tr');
                linea.innerHTML = `
                <td>${empresa.id}</td>
                <td>${empresa.name}</td>
                <td>${empresa.industry}</td>
                <td>${empresa.sector}</td>
                <td>${empresa.capital}</td>
                `;
                //Si ya esta le marca solo
                if (selectedCompanies.includes(empresa.id)) {
                    linea.classList.add("marcada");
                }
                //Evento para marcar/desmarcar
                linea.addEventListener('click', () => {
                    if (linea.classList.contains('marcada')) {
                      selectedCompanies.splice(selectedCompanies.indexOf(empresa.id), 1);
                      localStorage.setItem("selectedCompanies", JSON.stringify(selectedCompanies));
                      linea.classList.remove('marcada');
                    } else {
                      selectedCompanies.push(empresa.id);
                      localStorage.setItem("selectedCompanies", JSON.stringify(selectedCompanies));
                      linea.classList.add('marcada');
                    }
                  });
                
                TBODY.appendChild(linea);
                
            });

        })
        .catch(error => console.log('error', error));
}
//Insertar empresas
enviar.addEventListener('click', insertarEmpresa)

function insertarEmpresa() {
    console.log('hoa');
    let empresa = {
        "name": NAME.value,
        "industry": industry.value,
        "sector": sector.value,
        'capital': capital.value
    };
    fetch(url, {
        method: "POST",
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(empresa)
    })
        .then(res => res.json())
        .then(json => {
            console.log(json);
            cargarEmpresas();
        });

}

