//Toda la wea
const url = 'http://localhost:3000/api/contacts/';
const lista = document.querySelector('#contacts');
const selectedCompanies = JSON.parse(localStorage.getItem("selectedCompanies"));
if (selectedCompanies.length == 0) {
    cargarFicha();
} else {
    cargarFichaEspecifica()
}


function cargarFicha() {
    fetch(url)
        .then(response => response.json())
        .then(data => {
            console.log(data);
            data.forEach(contact => {
                linea = document.createElement('div');
                linea.classList.add('card');
                linea.innerHTML = `
            ID: ${contact.id}|Nombre: ${contact.first_name}|Apellidos: ${contact.last_name}
            |Departamento: ${contact.department}|Email: ${contact.email}|Compañia ${contact.company_id} 
            <img src="img/${contact.image}" alt="fotito"></img> <button onclick="borrar(this)">Borrar Contacto</button> `;
                lista.appendChild(linea);
            });
        })
}

function cargarFichaEspecifica() {
    fetch(url)
        .then(response => response.json())
        .then(data => {
            console.log(data);
            data.forEach(contact => {
                if (selectedCompanies.includes(contact.company_id)) {
                    linea = document.createElement('div');
                    linea.classList.add('card');
                    linea.innerHTML = `
            ID: ${contact.id}|Nombre: ${contact.first_name}|Apellidos: ${contact.last_name}
            |Departamento: ${contact.department}|Email: ${contact.email}|Compañia ${contact.company_id} 
            <img src="img/${contact.image}" alt="fotito"></img>  <button onclick="borrar(this)">Borrar Contacto</button>`;
                    lista.appendChild(linea);
                }
            });
        })
}

function borrar(elem) {
    elem.parentElement.remove()
}